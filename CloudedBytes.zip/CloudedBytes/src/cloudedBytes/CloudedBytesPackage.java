/**
 */
package cloudedBytes;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see cloudedBytes.CloudedBytesFactory
 * @model kind="package"
 * @generated
 */
public interface CloudedBytesPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "cloudedBytes";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/cloudedBytes";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "cloudedBytes";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CloudedBytesPackage eINSTANCE = cloudedBytes.impl.CloudedBytesPackageImpl.init();

	/**
	 * The meta object id for the '{@link cloudedBytes.impl.CloudedBytesImpl <em>Clouded Bytes</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cloudedBytes.impl.CloudedBytesImpl
	 * @see cloudedBytes.impl.CloudedBytesPackageImpl#getCloudedBytes()
	 * @generated
	 */
	int CLOUDED_BYTES = 0;

	/**
	 * The feature id for the '<em><b>Site Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUDED_BYTES__SITE_TITLE = 0;

	/**
	 * The feature id for the '<em><b>Posts</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUDED_BYTES__POSTS = 1;

	/**
	 * The feature id for the '<em><b>Site Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUDED_BYTES__SITE_DESCRIPTION = 2;

	/**
	 * The feature id for the '<em><b>Domain Address</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUDED_BYTES__DOMAIN_ADDRESS = 3;

	/**
	 * The number of structural features of the '<em>Clouded Bytes</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUDED_BYTES_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Clouded Bytes</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUDED_BYTES_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link cloudedBytes.impl.PostsImpl <em>Posts</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cloudedBytes.impl.PostsImpl
	 * @see cloudedBytes.impl.CloudedBytesPackageImpl#getPosts()
	 * @generated
	 */
	int POSTS = 1;

	/**
	 * The feature id for the '<em><b>Comment</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSTS__COMMENT = 0;

	/**
	 * The feature id for the '<em><b>Category</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSTS__CATEGORY = 1;

	/**
	 * The feature id for the '<em><b>Tag</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSTS__TAG = 2;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSTS__TITLE = 3;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSTS__CONTENT = 4;

	/**
	 * The feature id for the '<em><b>Post Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSTS__POST_DATE = 5;

	/**
	 * The number of structural features of the '<em>Posts</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSTS_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Posts</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSTS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link cloudedBytes.impl.CategoryImpl <em>Category</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cloudedBytes.impl.CategoryImpl
	 * @see cloudedBytes.impl.CloudedBytesPackageImpl#getCategory()
	 * @generated
	 */
	int CATEGORY = 2;

	/**
	 * The feature id for the '<em><b>Posts</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATEGORY__POSTS = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATEGORY__NAME = 1;

	/**
	 * The number of structural features of the '<em>Category</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATEGORY_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Category</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATEGORY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link cloudedBytes.impl.CommentImpl <em>Comment</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cloudedBytes.impl.CommentImpl
	 * @see cloudedBytes.impl.CloudedBytesPackageImpl#getComment()
	 * @generated
	 */
	int COMMENT = 3;

	/**
	 * The feature id for the '<em><b>Username</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMENT__USERNAME = 0;

	/**
	 * The feature id for the '<em><b>Email</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMENT__EMAIL = 1;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMENT__CONTENT = 2;

	/**
	 * The feature id for the '<em><b>Comment Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMENT__COMMENT_DATE = 3;

	/**
	 * The number of structural features of the '<em>Comment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMENT_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Comment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link cloudedBytes.impl.AuthorImpl <em>Author</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cloudedBytes.impl.AuthorImpl
	 * @see cloudedBytes.impl.CloudedBytesPackageImpl#getAuthor()
	 * @generated
	 */
	int AUTHOR = 4;

	/**
	 * The feature id for the '<em><b>Posts</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHOR__POSTS = 0;

	/**
	 * The feature id for the '<em><b>Author Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHOR__AUTHOR_NAME = 1;

	/**
	 * The feature id for the '<em><b>About</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHOR__ABOUT = 2;

	/**
	 * The number of structural features of the '<em>Author</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHOR_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Author</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link cloudedBytes.impl.TagImpl <em>Tag</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cloudedBytes.impl.TagImpl
	 * @see cloudedBytes.impl.CloudedBytesPackageImpl#getTag()
	 * @generated
	 */
	int TAG = 5;

	/**
	 * The feature id for the '<em><b>Posts</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAG__POSTS = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAG__NAME = 1;

	/**
	 * The number of structural features of the '<em>Tag</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAG_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Tag</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAG_OPERATION_COUNT = 0;


	/**
	 * Returns the meta object for class '{@link CloudedBytes <em>Clouded Bytes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Clouded Bytes</em>'.
	 * @see CloudedBytes
	 * @model instanceClass="CloudedBytes"
	 * @generated
	 */
	EClass getCloudedBytes();

	/**
	 * Returns the meta object for the attribute '{@link CloudedBytes#getSiteTitle <em>Site Title</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Site Title</em>'.
	 * @see CloudedBytes#getSiteTitle()
	 * @see #getCloudedBytes()
	 * @generated
	 */
	EAttribute getCloudedBytes_SiteTitle();

	/**
	 * Returns the meta object for the reference list '{@link CloudedBytes#getPosts <em>Posts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Posts</em>'.
	 * @see CloudedBytes#getPosts()
	 * @see #getCloudedBytes()
	 * @generated
	 */
	EReference getCloudedBytes_Posts();

	/**
	 * Returns the meta object for the attribute '{@link CloudedBytes#getSiteDescription <em>Site Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Site Description</em>'.
	 * @see CloudedBytes#getSiteDescription()
	 * @see #getCloudedBytes()
	 * @generated
	 */
	EAttribute getCloudedBytes_SiteDescription();

	/**
	 * Returns the meta object for the attribute '{@link CloudedBytes#getDomainAddress <em>Domain Address</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Domain Address</em>'.
	 * @see CloudedBytes#getDomainAddress()
	 * @see #getCloudedBytes()
	 * @generated
	 */
	EAttribute getCloudedBytes_DomainAddress();

	/**
	 * Returns the meta object for class '{@link Posts <em>Posts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Posts</em>'.
	 * @see Posts
	 * @model instanceClass="Posts"
	 * @generated
	 */
	EClass getPosts();

	/**
	 * Returns the meta object for the reference list '{@link Posts#getComment <em>Comment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Comment</em>'.
	 * @see Posts#getComment()
	 * @see #getPosts()
	 * @generated
	 */
	EReference getPosts_Comment();

	/**
	 * Returns the meta object for the reference list '{@link Posts#getCategory <em>Category</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Category</em>'.
	 * @see Posts#getCategory()
	 * @see #getPosts()
	 * @generated
	 */
	EReference getPosts_Category();

	/**
	 * Returns the meta object for the reference list '{@link Posts#getTag <em>Tag</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Tag</em>'.
	 * @see Posts#getTag()
	 * @see #getPosts()
	 * @generated
	 */
	EReference getPosts_Tag();

	/**
	 * Returns the meta object for the attribute '{@link Posts#getTitle <em>Title</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Title</em>'.
	 * @see Posts#getTitle()
	 * @see #getPosts()
	 * @generated
	 */
	EAttribute getPosts_Title();

	/**
	 * Returns the meta object for the attribute '{@link Posts#getContent <em>Content</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Content</em>'.
	 * @see Posts#getContent()
	 * @see #getPosts()
	 * @generated
	 */
	EAttribute getPosts_Content();

	/**
	 * Returns the meta object for the attribute '{@link Posts#getPostDate <em>Post Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Post Date</em>'.
	 * @see Posts#getPostDate()
	 * @see #getPosts()
	 * @generated
	 */
	EAttribute getPosts_PostDate();

	/**
	 * Returns the meta object for class '{@link Category <em>Category</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Category</em>'.
	 * @see Category
	 * @model instanceClass="Category"
	 * @generated
	 */
	EClass getCategory();

	/**
	 * Returns the meta object for the reference list '{@link Category#getPosts <em>Posts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Posts</em>'.
	 * @see Category#getPosts()
	 * @see #getCategory()
	 * @generated
	 */
	EReference getCategory_Posts();

	/**
	 * Returns the meta object for the attribute '{@link Category#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see Category#getName()
	 * @see #getCategory()
	 * @generated
	 */
	EAttribute getCategory_Name();

	/**
	 * Returns the meta object for class '{@link Comment <em>Comment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Comment</em>'.
	 * @see Comment
	 * @model instanceClass="Comment"
	 * @generated
	 */
	EClass getComment();

	/**
	 * Returns the meta object for the attribute '{@link Comment#getUsername <em>Username</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Username</em>'.
	 * @see Comment#getUsername()
	 * @see #getComment()
	 * @generated
	 */
	EAttribute getComment_Username();

	/**
	 * Returns the meta object for the attribute '{@link Comment#getEmail <em>Email</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Email</em>'.
	 * @see Comment#getEmail()
	 * @see #getComment()
	 * @generated
	 */
	EAttribute getComment_Email();

	/**
	 * Returns the meta object for the attribute '{@link Comment#getContent <em>Content</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Content</em>'.
	 * @see Comment#getContent()
	 * @see #getComment()
	 * @generated
	 */
	EAttribute getComment_Content();

	/**
	 * Returns the meta object for the attribute '{@link Comment#getCommentDate <em>Comment Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Comment Date</em>'.
	 * @see Comment#getCommentDate()
	 * @see #getComment()
	 * @generated
	 */
	EAttribute getComment_CommentDate();

	/**
	 * Returns the meta object for class '{@link Author <em>Author</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Author</em>'.
	 * @see Author
	 * @model instanceClass="Author" typeParameters="ValidAuthorName"
	 * @generated
	 */
	EClass getAuthor();

	/**
	 * Returns the meta object for the reference list '{@link Author#getPosts <em>Posts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Posts</em>'.
	 * @see Author#getPosts()
	 * @see #getAuthor()
	 * @generated
	 */
	EReference getAuthor_Posts();

	/**
	 * Returns the meta object for the attribute '{@link Author#getAuthorName <em>Author Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Author Name</em>'.
	 * @see Author#getAuthorName()
	 * @see #getAuthor()
	 * @generated
	 */
	EAttribute getAuthor_AuthorName();

	/**
	 * Returns the meta object for the attribute '{@link Author#getAbout <em>About</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>About</em>'.
	 * @see Author#getAbout()
	 * @see #getAuthor()
	 * @generated
	 */
	EAttribute getAuthor_About();

	/**
	 * Returns the meta object for class '{@link Tag <em>Tag</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tag</em>'.
	 * @see Tag
	 * @model instanceClass="Tag"
	 * @generated
	 */
	EClass getTag();

	/**
	 * Returns the meta object for the reference list '{@link Tag#getPosts <em>Posts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Posts</em>'.
	 * @see Tag#getPosts()
	 * @see #getTag()
	 * @generated
	 */
	EReference getTag_Posts();

	/**
	 * Returns the meta object for the attribute '{@link Tag#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see Tag#getName()
	 * @see #getTag()
	 * @generated
	 */
	EAttribute getTag_Name();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	CloudedBytesFactory getCloudedBytesFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link cloudedBytes.impl.CloudedBytesImpl <em>Clouded Bytes</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cloudedBytes.impl.CloudedBytesImpl
		 * @see cloudedBytes.impl.CloudedBytesPackageImpl#getCloudedBytes()
		 * @generated
		 */
		EClass CLOUDED_BYTES = eINSTANCE.getCloudedBytes();

		/**
		 * The meta object literal for the '<em><b>Site Title</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUDED_BYTES__SITE_TITLE = eINSTANCE.getCloudedBytes_SiteTitle();

		/**
		 * The meta object literal for the '<em><b>Posts</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUDED_BYTES__POSTS = eINSTANCE.getCloudedBytes_Posts();

		/**
		 * The meta object literal for the '<em><b>Site Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUDED_BYTES__SITE_DESCRIPTION = eINSTANCE.getCloudedBytes_SiteDescription();

		/**
		 * The meta object literal for the '<em><b>Domain Address</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUDED_BYTES__DOMAIN_ADDRESS = eINSTANCE.getCloudedBytes_DomainAddress();

		/**
		 * The meta object literal for the '{@link cloudedBytes.impl.PostsImpl <em>Posts</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cloudedBytes.impl.PostsImpl
		 * @see cloudedBytes.impl.CloudedBytesPackageImpl#getPosts()
		 * @generated
		 */
		EClass POSTS = eINSTANCE.getPosts();

		/**
		 * The meta object literal for the '<em><b>Comment</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference POSTS__COMMENT = eINSTANCE.getPosts_Comment();

		/**
		 * The meta object literal for the '<em><b>Category</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference POSTS__CATEGORY = eINSTANCE.getPosts_Category();

		/**
		 * The meta object literal for the '<em><b>Tag</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference POSTS__TAG = eINSTANCE.getPosts_Tag();

		/**
		 * The meta object literal for the '<em><b>Title</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POSTS__TITLE = eINSTANCE.getPosts_Title();

		/**
		 * The meta object literal for the '<em><b>Content</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POSTS__CONTENT = eINSTANCE.getPosts_Content();

		/**
		 * The meta object literal for the '<em><b>Post Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POSTS__POST_DATE = eINSTANCE.getPosts_PostDate();

		/**
		 * The meta object literal for the '{@link cloudedBytes.impl.CategoryImpl <em>Category</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cloudedBytes.impl.CategoryImpl
		 * @see cloudedBytes.impl.CloudedBytesPackageImpl#getCategory()
		 * @generated
		 */
		EClass CATEGORY = eINSTANCE.getCategory();

		/**
		 * The meta object literal for the '<em><b>Posts</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CATEGORY__POSTS = eINSTANCE.getCategory_Posts();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CATEGORY__NAME = eINSTANCE.getCategory_Name();

		/**
		 * The meta object literal for the '{@link cloudedBytes.impl.CommentImpl <em>Comment</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cloudedBytes.impl.CommentImpl
		 * @see cloudedBytes.impl.CloudedBytesPackageImpl#getComment()
		 * @generated
		 */
		EClass COMMENT = eINSTANCE.getComment();

		/**
		 * The meta object literal for the '<em><b>Username</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMMENT__USERNAME = eINSTANCE.getComment_Username();

		/**
		 * The meta object literal for the '<em><b>Email</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMMENT__EMAIL = eINSTANCE.getComment_Email();

		/**
		 * The meta object literal for the '<em><b>Content</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMMENT__CONTENT = eINSTANCE.getComment_Content();

		/**
		 * The meta object literal for the '<em><b>Comment Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMMENT__COMMENT_DATE = eINSTANCE.getComment_CommentDate();

		/**
		 * The meta object literal for the '{@link cloudedBytes.impl.AuthorImpl <em>Author</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cloudedBytes.impl.AuthorImpl
		 * @see cloudedBytes.impl.CloudedBytesPackageImpl#getAuthor()
		 * @generated
		 */
		EClass AUTHOR = eINSTANCE.getAuthor();

		/**
		 * The meta object literal for the '<em><b>Posts</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AUTHOR__POSTS = eINSTANCE.getAuthor_Posts();

		/**
		 * The meta object literal for the '<em><b>Author Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AUTHOR__AUTHOR_NAME = eINSTANCE.getAuthor_AuthorName();

		/**
		 * The meta object literal for the '<em><b>About</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AUTHOR__ABOUT = eINSTANCE.getAuthor_About();

		/**
		 * The meta object literal for the '{@link cloudedBytes.impl.TagImpl <em>Tag</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cloudedBytes.impl.TagImpl
		 * @see cloudedBytes.impl.CloudedBytesPackageImpl#getTag()
		 * @generated
		 */
		EClass TAG = eINSTANCE.getTag();

		/**
		 * The meta object literal for the '<em><b>Posts</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAG__POSTS = eINSTANCE.getTag_Posts();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TAG__NAME = eINSTANCE.getTag_Name();

	}

} //CloudedBytesPackage
