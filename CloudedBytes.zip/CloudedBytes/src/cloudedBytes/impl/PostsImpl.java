/**
 */
package cloudedBytes.impl;

import cloudedBytes.CloudedBytesPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Posts</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link cloudedBytes.impl.PostsImpl#getComment <em>Comment</em>}</li>
 *   <li>{@link cloudedBytes.impl.PostsImpl#getCategory <em>Category</em>}</li>
 *   <li>{@link cloudedBytes.impl.PostsImpl#getTag <em>Tag</em>}</li>
 *   <li>{@link cloudedBytes.impl.PostsImpl#getTitle <em>Title</em>}</li>
 *   <li>{@link cloudedBytes.impl.PostsImpl#getContent <em>Content</em>}</li>
 *   <li>{@link cloudedBytes.impl.PostsImpl#getPostDate <em>Post Date</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PostsImpl extends MinimalEObjectImpl.Container implements Posts {
	/**
	 * The cached value of the '{@link #getComment() <em>Comment</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComment()
	 * @generated
	 * @ordered
	 */
	protected EList<Comment> comment;

	/**
	 * The cached value of the '{@link #getCategory() <em>Category</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCategory()
	 * @generated
	 * @ordered
	 */
	protected EList<Category> category;

	/**
	 * The cached value of the '{@link #getTag() <em>Tag</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTag()
	 * @generated
	 * @ordered
	 */
	protected EList<Tag> tag;

	/**
	 * The default value of the '{@link #getTitle() <em>Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTitle()
	 * @generated
	 * @ordered
	 */
	protected static final String TITLE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTitle() <em>Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTitle()
	 * @generated
	 * @ordered
	 */
	protected String title = TITLE_EDEFAULT;

	/**
	 * The default value of the '{@link #getContent() <em>Content</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContent()
	 * @generated
	 * @ordered
	 */
	protected static final String CONTENT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getContent() <em>Content</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContent()
	 * @generated
	 * @ordered
	 */
	protected String content = CONTENT_EDEFAULT;

	/**
	 * The default value of the '{@link #getPostDate() <em>Post Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPostDate()
	 * @generated
	 * @ordered
	 */
	protected static final String POST_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPostDate() <em>Post Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPostDate()
	 * @generated
	 * @ordered
	 */
	protected String postDate = POST_DATE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PostsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CloudedBytesPackage.Literals.POSTS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Comment> getComment() {
		if (comment == null) {
			comment = new EObjectResolvingEList<Comment>(Comment.class, this, CloudedBytesPackage.POSTS__COMMENT);
		}
		return comment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Category> getCategory() {
		if (category == null) {
			category = new EObjectWithInverseResolvingEList.ManyInverse<Category>(Category.class, this, CloudedBytesPackage.POSTS__CATEGORY, CloudedBytesPackage.CATEGORY__POSTS);
		}
		return category;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Tag> getTag() {
		if (tag == null) {
			tag = new EObjectWithInverseResolvingEList.ManyInverse<Tag>(Tag.class, this, CloudedBytesPackage.POSTS__TAG, CloudedBytesPackage.TAG__POSTS);
		}
		return tag;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getTitle() {
		return title;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setTitle(String newTitle) {
		String oldTitle = title;
		title = newTitle;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CloudedBytesPackage.POSTS__TITLE, oldTitle, title));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getContent() {
		return content;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setContent(String newContent) {
		String oldContent = content;
		content = newContent;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CloudedBytesPackage.POSTS__CONTENT, oldContent, content));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getPostDate() {
		return postDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPostDate(String newPostDate) {
		String oldPostDate = postDate;
		postDate = newPostDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CloudedBytesPackage.POSTS__POST_DATE, oldPostDate, postDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CloudedBytesPackage.POSTS__CATEGORY:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getCategory()).basicAdd(otherEnd, msgs);
			case CloudedBytesPackage.POSTS__TAG:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getTag()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CloudedBytesPackage.POSTS__CATEGORY:
				return ((InternalEList<?>)getCategory()).basicRemove(otherEnd, msgs);
			case CloudedBytesPackage.POSTS__TAG:
				return ((InternalEList<?>)getTag()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CloudedBytesPackage.POSTS__COMMENT:
				return getComment();
			case CloudedBytesPackage.POSTS__CATEGORY:
				return getCategory();
			case CloudedBytesPackage.POSTS__TAG:
				return getTag();
			case CloudedBytesPackage.POSTS__TITLE:
				return getTitle();
			case CloudedBytesPackage.POSTS__CONTENT:
				return getContent();
			case CloudedBytesPackage.POSTS__POST_DATE:
				return getPostDate();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CloudedBytesPackage.POSTS__COMMENT:
				getComment().clear();
				getComment().addAll((Collection<? extends Comment>)newValue);
				return;
			case CloudedBytesPackage.POSTS__CATEGORY:
				getCategory().clear();
				getCategory().addAll((Collection<? extends Category>)newValue);
				return;
			case CloudedBytesPackage.POSTS__TAG:
				getTag().clear();
				getTag().addAll((Collection<? extends Tag>)newValue);
				return;
			case CloudedBytesPackage.POSTS__TITLE:
				setTitle((String)newValue);
				return;
			case CloudedBytesPackage.POSTS__CONTENT:
				setContent((String)newValue);
				return;
			case CloudedBytesPackage.POSTS__POST_DATE:
				setPostDate((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CloudedBytesPackage.POSTS__COMMENT:
				getComment().clear();
				return;
			case CloudedBytesPackage.POSTS__CATEGORY:
				getCategory().clear();
				return;
			case CloudedBytesPackage.POSTS__TAG:
				getTag().clear();
				return;
			case CloudedBytesPackage.POSTS__TITLE:
				setTitle(TITLE_EDEFAULT);
				return;
			case CloudedBytesPackage.POSTS__CONTENT:
				setContent(CONTENT_EDEFAULT);
				return;
			case CloudedBytesPackage.POSTS__POST_DATE:
				setPostDate(POST_DATE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CloudedBytesPackage.POSTS__COMMENT:
				return comment != null && !comment.isEmpty();
			case CloudedBytesPackage.POSTS__CATEGORY:
				return category != null && !category.isEmpty();
			case CloudedBytesPackage.POSTS__TAG:
				return tag != null && !tag.isEmpty();
			case CloudedBytesPackage.POSTS__TITLE:
				return TITLE_EDEFAULT == null ? title != null : !TITLE_EDEFAULT.equals(title);
			case CloudedBytesPackage.POSTS__CONTENT:
				return CONTENT_EDEFAULT == null ? content != null : !CONTENT_EDEFAULT.equals(content);
			case CloudedBytesPackage.POSTS__POST_DATE:
				return POST_DATE_EDEFAULT == null ? postDate != null : !POST_DATE_EDEFAULT.equals(postDate);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Title: ");
		result.append(title);
		result.append(", Content: ");
		result.append(content);
		result.append(", PostDate: ");
		result.append(postDate);
		result.append(')');
		return result.toString();
	}

} //PostsImpl
