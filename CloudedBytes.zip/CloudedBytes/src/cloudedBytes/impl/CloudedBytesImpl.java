/**
 */
package cloudedBytes.impl;

import cloudedBytes.CloudedBytesPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Clouded Bytes</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link cloudedBytes.impl.CloudedBytesImpl#getSiteTitle <em>Site Title</em>}</li>
 *   <li>{@link cloudedBytes.impl.CloudedBytesImpl#getPosts <em>Posts</em>}</li>
 *   <li>{@link cloudedBytes.impl.CloudedBytesImpl#getSiteDescription <em>Site Description</em>}</li>
 *   <li>{@link cloudedBytes.impl.CloudedBytesImpl#getDomainAddress <em>Domain Address</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CloudedBytesImpl extends MinimalEObjectImpl.Container implements CloudedBytes {
	/**
	 * The default value of the '{@link #getSiteTitle() <em>Site Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSiteTitle()
	 * @generated
	 * @ordered
	 */
	protected static final String SITE_TITLE_EDEFAULT = "CloudedBytes";

	/**
	 * The cached value of the '{@link #getSiteTitle() <em>Site Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSiteTitle()
	 * @generated
	 * @ordered
	 */
	protected String siteTitle = SITE_TITLE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPosts() <em>Posts</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPosts()
	 * @generated
	 * @ordered
	 */
	protected EList<Posts> posts;

	/**
	 * The default value of the '{@link #getSiteDescription() <em>Site Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSiteDescription()
	 * @generated
	 * @ordered
	 */
	protected static final String SITE_DESCRIPTION_EDEFAULT = "";

	/**
	 * The cached value of the '{@link #getSiteDescription() <em>Site Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSiteDescription()
	 * @generated
	 * @ordered
	 */
	protected String siteDescription = SITE_DESCRIPTION_EDEFAULT;

	/**
	 * The default value of the '{@link #getDomainAddress() <em>Domain Address</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDomainAddress()
	 * @generated
	 * @ordered
	 */
	protected static final String DOMAIN_ADDRESS_EDEFAULT = "cloudedbytes";

	/**
	 * The cached value of the '{@link #getDomainAddress() <em>Domain Address</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDomainAddress()
	 * @generated
	 * @ordered
	 */
	protected String domainAddress = DOMAIN_ADDRESS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CloudedBytesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CloudedBytesPackage.Literals.CLOUDED_BYTES;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getSiteTitle() {
		return siteTitle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSiteTitle(String newSiteTitle) {
		String oldSiteTitle = siteTitle;
		siteTitle = newSiteTitle;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CloudedBytesPackage.CLOUDED_BYTES__SITE_TITLE, oldSiteTitle, siteTitle));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Posts> getPosts() {
		if (posts == null) {
			posts = new EObjectResolvingEList<Posts>(Posts.class, this, CloudedBytesPackage.CLOUDED_BYTES__POSTS);
		}
		return posts;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getSiteDescription() {
		return siteDescription;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSiteDescription(String newSiteDescription) {
		String oldSiteDescription = siteDescription;
		siteDescription = newSiteDescription;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CloudedBytesPackage.CLOUDED_BYTES__SITE_DESCRIPTION, oldSiteDescription, siteDescription));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getDomainAddress() {
		return domainAddress;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDomainAddress(String newDomainAddress) {
		String oldDomainAddress = domainAddress;
		domainAddress = newDomainAddress;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CloudedBytesPackage.CLOUDED_BYTES__DOMAIN_ADDRESS, oldDomainAddress, domainAddress));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CloudedBytesPackage.CLOUDED_BYTES__SITE_TITLE:
				return getSiteTitle();
			case CloudedBytesPackage.CLOUDED_BYTES__POSTS:
				return getPosts();
			case CloudedBytesPackage.CLOUDED_BYTES__SITE_DESCRIPTION:
				return getSiteDescription();
			case CloudedBytesPackage.CLOUDED_BYTES__DOMAIN_ADDRESS:
				return getDomainAddress();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CloudedBytesPackage.CLOUDED_BYTES__SITE_TITLE:
				setSiteTitle((String)newValue);
				return;
			case CloudedBytesPackage.CLOUDED_BYTES__POSTS:
				getPosts().clear();
				getPosts().addAll((Collection<? extends Posts>)newValue);
				return;
			case CloudedBytesPackage.CLOUDED_BYTES__SITE_DESCRIPTION:
				setSiteDescription((String)newValue);
				return;
			case CloudedBytesPackage.CLOUDED_BYTES__DOMAIN_ADDRESS:
				setDomainAddress((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CloudedBytesPackage.CLOUDED_BYTES__SITE_TITLE:
				setSiteTitle(SITE_TITLE_EDEFAULT);
				return;
			case CloudedBytesPackage.CLOUDED_BYTES__POSTS:
				getPosts().clear();
				return;
			case CloudedBytesPackage.CLOUDED_BYTES__SITE_DESCRIPTION:
				setSiteDescription(SITE_DESCRIPTION_EDEFAULT);
				return;
			case CloudedBytesPackage.CLOUDED_BYTES__DOMAIN_ADDRESS:
				setDomainAddress(DOMAIN_ADDRESS_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CloudedBytesPackage.CLOUDED_BYTES__SITE_TITLE:
				return SITE_TITLE_EDEFAULT == null ? siteTitle != null : !SITE_TITLE_EDEFAULT.equals(siteTitle);
			case CloudedBytesPackage.CLOUDED_BYTES__POSTS:
				return posts != null && !posts.isEmpty();
			case CloudedBytesPackage.CLOUDED_BYTES__SITE_DESCRIPTION:
				return SITE_DESCRIPTION_EDEFAULT == null ? siteDescription != null : !SITE_DESCRIPTION_EDEFAULT.equals(siteDescription);
			case CloudedBytesPackage.CLOUDED_BYTES__DOMAIN_ADDRESS:
				return DOMAIN_ADDRESS_EDEFAULT == null ? domainAddress != null : !DOMAIN_ADDRESS_EDEFAULT.equals(domainAddress);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (SiteTitle: ");
		result.append(siteTitle);
		result.append(", SiteDescription: ");
		result.append(siteDescription);
		result.append(", DomainAddress: ");
		result.append(domainAddress);
		result.append(')');
		return result.toString();
	}

} //CloudedBytesImpl
