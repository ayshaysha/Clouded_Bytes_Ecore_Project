/**
 */
package cloudedBytes.impl;

import cloudedBytes.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CloudedBytesFactoryImpl extends EFactoryImpl implements CloudedBytesFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static CloudedBytesFactory init() {
		try {
			CloudedBytesFactory theCloudedBytesFactory = (CloudedBytesFactory)EPackage.Registry.INSTANCE.getEFactory(CloudedBytesPackage.eNS_URI);
			if (theCloudedBytesFactory != null) {
				return theCloudedBytesFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new CloudedBytesFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CloudedBytesFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case CloudedBytesPackage.CLOUDED_BYTES: return (EObject)createCloudedBytes();
			case CloudedBytesPackage.POSTS: return (EObject)createPosts();
			case CloudedBytesPackage.CATEGORY: return (EObject)createCategory();
			case CloudedBytesPackage.COMMENT: return (EObject)createComment();
			case CloudedBytesPackage.AUTHOR: return (EObject)createAuthor();
			case CloudedBytesPackage.TAG: return (EObject)createTag();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CloudedBytes createCloudedBytes() {
		CloudedBytesImpl cloudedBytes = new CloudedBytesImpl();
		return cloudedBytes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Posts createPosts() {
		PostsImpl posts = new PostsImpl();
		return posts;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Category createCategory() {
		CategoryImpl category = new CategoryImpl();
		return category;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Comment createComment() {
		CommentImpl comment = new CommentImpl();
		return comment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public <ValidAuthorName> Author<ValidAuthorName> createAuthor() {
		AuthorImpl<ValidAuthorName> author = new AuthorImpl<ValidAuthorName>();
		return author;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Tag createTag() {
		TagImpl tag = new TagImpl();
		return tag;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CloudedBytesPackage getCloudedBytesPackage() {
		return (CloudedBytesPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static CloudedBytesPackage getPackage() {
		return CloudedBytesPackage.eINSTANCE;
	}

} //CloudedBytesFactoryImpl
